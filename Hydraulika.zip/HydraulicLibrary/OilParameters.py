
class OilParameters:

    def __init__(self):

        self.density = 900.0      # [kg/m^3]


